import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import HomeScreen from './screens/HomeScreen';
import GridScreen from './screens/GridScreen';
import ThemeScreen from './screens/ThemeScreen';
import Icon from 'react-native-vector-icons/Ionicons';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator 
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === 'Home') {
              iconName = focused ? 'home' : 'home-outline';
            } else if (route.name === 'Grid') {
              iconName = focused ? 'grid' : 'grid-outline';
            } else if (route.name === 'Theme') {
              iconName = focused ? 'color-palette' : 'color-palette-outline';
            } else if (route.name === 'Details') {
              iconName = focused ? 'information-circle' : 'information-circle-outline';
            } else if (route.name === 'Profile') {
              iconName = focused ? 'person' : 'person-outline';
            }

            return <Icon name={iconName} size={size} color={color} />;
          },
        })}
        tabBarOptions={{ activeTintColor: 'blue', inactiveTintColor: 'gray' }}
      >
        <Tab.Screen name="Home" component={HomeScreen} />
        <Tab.Screen name="Grid" component={GridScreen} />
        <Tab.Screen name="Theme" component={ThemeScreen} />
       
      </Tab.Navigator>
    </NavigationContainer>
  );
}
