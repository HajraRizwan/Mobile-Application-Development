import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const GridScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Grid Screen</Text>
      <Button title="Go to Theme" onPress={() => navigation.navigate('Theme')} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  text: { fontSize: 24, marginBottom: 10 },
});

export default GridScreen;
