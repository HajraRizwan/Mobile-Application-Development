
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import SearchBar from './components/SearchBar'; 
import Doctor from './components/Doctor'; 

export default function App() {
  return (
    <View style={styles.screen}>
      <SearchBar />
      <Text style={styles.headerText}>Let's find your doctor....</Text>

      <View style={styles.cardRow}>
        <Doctor name="Dr. John Smith" type="Dermatologist" score="4.9" />
        <Doctor name="Dr. Anna Dinn" type="Psychologist" score="4.9" />
      </View>

      <View style={styles.cardRow}>
        <Doctor name="Dr. Angela Rayez" type="Therapist" score="4.8" />
        <Doctor name="Dr. Chris Bronte" type="Dentist" score="5.0" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f0eaff', 
  },
  headerText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#3b3b3b',
  },
  cardRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});
