
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';

export default function Doctor(props) {
  return (

    <View style={styles.card}>
      <Icon name="user-md" size={40} color="#000" />
      <Text style={styles.nameText}>{props.name}</Text>  
      <Text style={styles.typeText}>{props.type}</Text>
      <View style={styles.scoreBox}>
        <Icon name="star" size={16} color="#FFDF00" />
        <Text style={styles.scoreText}>{props.score}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 20,
    margin: 10,
    borderRadius: 10,
   
  },
  nameText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginVertical: 5,
    color: '#3b3b3b',
  },
  typeText: {
    fontSize: 14,
    color: '#777',
  },
  scoreBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#6a0dad',
    borderRadius: 15,
    paddingVertical: 5,
    paddingHorizontal: 10,
    marginTop: 10,
  },
  scoreText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#fff',
    marginLeft: 5,
  },
});


