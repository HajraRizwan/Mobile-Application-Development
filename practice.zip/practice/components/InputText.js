import React, { useState } from 'react';
import { TextInput, View, Text } from 'react-native';

export default function Input_ex() {
  const [inputText, setInputText] = useState("");

  const handleTextChange = (text) => {
    setInputText(text);
    console.log(text);
  };

  return (
    <View >
      <TextInput
       placeholder="Type here..."
       onChangeText={handleTextChange}
      />
      <Text>{inputText}</Text>
    </View>
  );
}
