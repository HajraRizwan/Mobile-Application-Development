import React from 'react';
import { View, StyleSheet } from 'react-native';

export default function FlexBox() {
  return (
    <View style={styles.container}>
      <View style={styles.box1} />
      <View style={styles.box2} />
      <View style={styles.box3} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  box1: {
    flex: 1,
    backgroundColor: 'red',
    height: 100,
  },
  box2: {
    flex: 2,
    backgroundColor: 'orange',
    height: 100,
  },
  box3: {
    flex: 3,
    backgroundColor: 'green',
    height: 100,
  },
});
