
import React from 'react';
import {Text, TextInput, ScrollView, StyleSheet, View} from 'react-native';

export default function State_ex(props)
{
  return (
    <>
         <View style={styles.card}>
         {props.name}{props.title}
         </View>   
    </>
  );
}

const styles =StyleSheet.create(
  {
    card:
    {
     flexDirection: 'row',
     borderWidth:1,
     backgroundColor:'light',
     text : 'center',
     padding:12,
     paddingLeft:20,

    },
  }
)