import React, { useState } from 'react';
import { TextInput, Button, View } from 'react-native';

export default function App() {
  const [inputText, setInputText] = useState("");

  const handleTextChange = (text) => {
    setInputText(text);
  };

  const handlePress = () => {
    console.log(inputText);
  };

  return (
    <View>
      <TextInput
       
        placeholder="Type something..."
        onChangeText={handleTextChange}
      />
      <Button
        title={inputText || "Log Text"}
        onPress={handlePress}
        color="blue"
      />
    </View>
  );
}
