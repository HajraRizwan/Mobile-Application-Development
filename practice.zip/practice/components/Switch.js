import React, { useState } from 'react';
import { View, Text, Switch, StyleSheet } from 'react-native';

export default function Switch_ex() {
  const [isEnabled, setIsEnabled] = useState(false); // State to manage switch value

  const toggleSwitch = () => setIsEnabled(previousState => !previousState); // Toggle function

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Switch is {isEnabled ? "ON" : "OFF"}</Text>
      <Switch
        value={isEnabled}
        onValueChange={toggleSwitch} // Call toggle function on change
        trackColor={{ false: "#767577", true: "#81b0ff" }} // Colors for track
        thumbColor={isEnabled ? "#f5dd4b" : "#f4f3f4"} // Color of thumb
        ios_backgroundColor="#3e3e3e" // Background color on iOS
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontSize: 18,
    marginBottom: 20,
  },
});
