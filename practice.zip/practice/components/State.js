import React,{useState} from 'react';
import {View,Button} from 'react-native';

export default function Props_ex()
{
 const [text,setText]=useState("hello");
  return (
<Button title={text} onPress={()=> setText(text==="hello" ? "Bye" : "Hello")}/>
         );
}


