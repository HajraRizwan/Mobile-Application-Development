import React from 'react';
import { View, Text, ImageBackground, Image, StyleSheet } from 'react-native';

export default function Image_ex() {
  return (
    <View style={styles.container}>
      {/* Local Image as Background */}
      <ImageBackground 
        source={require('../assets/snack-icon.png')} // Local image
        style={styles.background}
      >
        <Text style={styles.text}>Inside Background</Text>
      </ImageBackground>

      {/* Online Image */}
      <Image 
        source={{ uri: 'https://encrypted-tbn3.gstatic.com/licensed-image?q=tbn:ANd9GcTZz-LMjJQqLKktDFQx_spwH-_9dvE6Dpc_oyz3Jb2rnGlRKjM2ik7Zmr8V2DEf-UnCJEnAp5YK5KLHJDI' }} // Replace with your online image URL
        style={styles.onlineImage}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  background: {
    width: '100%', // Full width
    height: '100%', // Full height
    justifyContent: 'center', // Center content vertically
    alignItems: 'center', // Center content horizontally
  },
  text: {
    color: 'white', // Text color
    fontSize: 24, // Text size
  },
  onlineImage: {
    width: 200, // Width of the online image
    height: 200, // Height of the online image
    marginTop: 20, // Space between the background and online image
  },
});
