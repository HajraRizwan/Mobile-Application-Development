import React from 'react';
import { View, Text, StyleSheet, StatusBar } from 'react-native';

export default function StatusBar_ex() {
  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" hidden={false} backgroundColor="#000" /> {/* Optional background color */}
      <Text style={styles.text}>Hello, World!</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#282c34', // Dark background for contrast
  },
  text: {
    color: 'white', // Light text for visibility
    fontSize: 24,
  },
});
