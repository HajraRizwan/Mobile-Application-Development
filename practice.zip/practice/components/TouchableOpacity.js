import React from 'react';
import { View, TouchableOpacity, Text, Image, StyleSheet } from 'react-native';

export default function TA() {
  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => console.log("Pressed!")}>
        <View style={styles.button}>
          <Image source={require('../assets/snack-icon.png')} style={styles.icon} />
          <Text style={styles.buttonText}>Click Me!</Text>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    backgroundColor: '#188a9b',
    borderRadius: 5,
  },
  icon: {
    width: 20, // Set the width of the icon
    height: 20, // Set the height of the icon
    marginRight: 10, // Add some space between the icon and text
  },
  buttonText: {
    color: 'white',
  },
});
