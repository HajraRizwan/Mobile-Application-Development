import React, { useState } from 'react';
import { View, Button, Text } from 'react-native';

export default function State2() {
  const [text, setText] = useState("Hello"); 

  return (
    <View>
      <Text >{text}</Text>

      <Button 
        title={text === "Hello" ? "Bye" : "Hello"}
        onPress={() => setText(text === "Hello" ? "Bye" : "Hello")} 
      />
    </View>
  );
}
