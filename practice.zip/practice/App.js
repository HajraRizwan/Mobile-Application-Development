import React from 'react';
import { Text, ScrollView, StyleSheet, View } from 'react-native';
import Props_ex from './components/Props';
import State_ex from './components/State';
import State2_ex from './components/State2';
import Input_ex from './components/InputText';
import ButtonText from './components/ButtonText';
import FlexBox from './components/FlexBox';
import TA from './components/TouchableOpacity';
import Image_ex from './components/Image';
import Switch_ex from './components/Switch';
import StatusBar_ex from './components/StatusBar';
export default function App() {
  return (
    <ScrollView style={styles.scrollView}> {/* Wrap everything inside ScrollView */}
      <View style={styles.container}>

        <Text style={styles.header}>Home</Text>
        <StatusBar_ex/>
        <Props_ex name="Hajra" />
        <State_ex /> 
        <Switch_ex />
        <State2_ex />
        <Input_ex />
        <ButtonText />
        <FlexBox />
        <TA />
        <Image_ex />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    flex: 1, // Allow ScrollView to fill the container
  },
  container: {
    padding: 16, // Add some padding around the content
  },
  header: {
    fontSize: 24, // Larger font size for the header
    marginBottom: 20, // Space below the header
    textAlign: 'center', // Center the header text
  },
});
